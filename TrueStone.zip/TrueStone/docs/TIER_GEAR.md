# Tier gear (PC)

ITEMOBJECT.DAT **LEVEL at +278** gates item power/availability in data.

TrueStone lowers LEVEL by `itemLevelReduction` (default 18) and can force Expert/Hero-tier rows down to `expertHeroReleaseLevel`.

**Install `data\itemobject.dat`** after a run. If shops/drops look vanilla, the DAT was not installed.

Difficulty mode in the EXE may still bias loot independently — full dual-difficulty loot table is future EXE RE.
