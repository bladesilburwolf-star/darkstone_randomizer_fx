# Trapped chests & spell books (v1.18.0)

## Behavior
| Option | SCRIPT effect |
|--------|----------------|
| **Ambush chests** | Non-quest CHEST/COFFRE/… OBJECT → `FLAG { …\|TRAP }` |
| **Trapped spell books** | BOOK/PUPITRE/`ITEM_BOOK_*` / OBJECTMOUSE stands → TRAP |
| **Open-cast random spells** | Existing TRAP `PROJECTILE KEY` + `EFFECT` rewritten |

### Open-cast catalog (retail names)
- Projectiles: `fireball`, `magicmiss`, `fleche`, `magicbonb`, `venom`, `shuriken`
- Harmful FX: `explode`, `poisoned`, `absorbma`, `teleport`, `firecamp`, `absorbvi`, `magic1`, `rip`
- Mild surprises: `heal1`, `maglight`, `smoke`, `etincel`

Quest/VIRTUAL/KEY objects are protected. Install `Out/SCRIPT/*.SPT` via MTF or loose override.

## Not true mimics
No walking chest AI — same as KF: open → trap/projectile. Book stands that already fire (Medusa `vbook`/`gorfireball`) get shuffled spell types.
