# XP & levels (PC research 2026-09-09)

## Player observation
Hard (high damage) goblins give **little XP**. Semi-hard bats / many strikes level **quickly**.
**Combat power ≠ XP.** Buffing DMIN/DMAX/AC does not increase experience.

## DAT fields (MONSTERCLASS.DAT stride 584)

| Offset | Export name | Role |
|--------|-------------|------|
| **+66** | **LEVEL** | Template level id (BAT1=2, GOBELIN=1, WIZA1=59) — **best XP candidate** |
| +68 / +72 | LMIN / LMAX | Spawn level band (where they appear), not the same as LEVEL |
| +76..+88 | AC / TOHIT / DMIN / DMAX | Combat only |
| +102/+106/+110 | ? | Often 50/50/100 even on weak trash — **not** unique XP per type |

Hard goblins after power scaling can still have **LEVEL 1–4** → low XP if the engine keys off +66.
Bats that take many hits may pay out more if XP is **hit- or damage-share based**, or if their LEVEL sits closer to the player.

## EXE surfaces
- `STEXPERIENCE`, `KILLS`, `STPTSLEVEL`, `STMAXEXP` (UI/stat strings)
- Level-up attribute points are separate from "kill XP rate"
- Old tip: banking unspent points can keep early levels feeling faster

## Hypotheses (to confirm in-game)
1. Kill XP scales with **monster LEVEL (+66)** vs **player level** (sweet spot; too high/low = less).
2. And/or XP scales with **hits landed or % HP dealt**, not with monster damage.
3. **No dedicated XP column** found that differs BAT vs GOBELIN while combat differs.

## Randomizer implication
- Do **not** expect monster power scale / elite templates to raise XP.
- Future: optional **LEVEL (+66) align** toward player band, or a dedicated XP scale once formula is locked in EXE.
- Post–level-16 slowdown is a separate curve (XP-to-next-level), still unmapped safely.

## Test plan
1. Clean DAT: kill 10× BAT1 and 10× GOBELIN at same player level — compare bar fill.
2. Patch only +66 upward on GOBELIN, leave combat — retest XP.
3. Patch only DMAX upward, leave +66 — confirm XP unchanged.


## Implemented (v1.12.4)

**Monster LEVEL / XP (+66)** option (default on):
- Shuffles LEVEL values within **LMAX spawn tiers** so area progression stays roughly sane
- Does **not** change DMAX/AC; those stay separate combat knobs
- Log: `Monster LEVEL (+66) XP field: N reassignments`

Global shuffle: set `monsterLevelBySpawnTier = false` in options (advanced later).

## v1.12.5 — no more whole-tier identity swaps
Wyverns in Ardyl came from **full DAT record swaps** (enemy types), not LEVEL+66 alone.
- **Removed from UI:** enemy types / types per land-dungeon tier
- **LEVEL option:** XP tag shuffle + early soft-nerf (×0.72) + ~1/8 invasion (later types, LMIN early, combat ×0.45–0.70)
- Models stay themselves; invasion is LMIN/LMAX + scaled stats, not “all of land 4 becomes land 1”
