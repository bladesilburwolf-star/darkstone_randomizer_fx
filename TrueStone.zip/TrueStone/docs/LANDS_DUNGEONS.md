# Lands & Dungeons (PC)

## v1.12.8

| Feature | Status |
|---------|--------|
| **Dungeon trap variety** | SCRIPT trap ACTION tokens shuffled in same-length groups (teleport/hit/monster/effect). CHANGELEVEL destinations **not** remapped (soft-lock risk). |
| **Dungeon visual/mesh variety** | Same-length `.O3D`/`.TGA` path swaps inside SCRIPT. Not overworld land tiles. |
| **LAND prop O3D shuffle** | Existing same-size mesh shuffle under LAND/. |
| Level doors within/cross | Still experimental / not reliable |
| Full procedural layout graph | Engine generates MLV from seed — not a static tile file we rewrite |

## Trap types (EXE)
`_TRAP_STATE_ACTION_TELEPORT2ND`, `HIT`, `MONSTER`, `SOUND`, `EFFECT`, `CHANGELEVEL`, etc.
Land 2 Gate of the Damned / land 4 Amazon hideout use switch teleport traps — variety pass spreads those action classes across scripts.

## Install
`SCRIPT/*.SPT` via MTF inject or `data\SCRIPT\`. `itemobject.dat` for spell books.
