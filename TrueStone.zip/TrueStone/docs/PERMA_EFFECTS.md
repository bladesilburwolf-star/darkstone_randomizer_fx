# Permanent effects research (TrueStone PC)

## EXE string table (Darkstone_patched.exe)
| ID (community) | Symbol |
|----------------|--------|
| 40 | MAGIC_ABONDANCE2 (no hunger) |
| 41 | MAGIC_REGENLIFE |
| 42 | MAGIC_REGENMANA |
| 43 | MAGIC_SLOWPOISON |
| 44 | MAGIC_LUMIERE (light aura) |
| 45 | MAGIC_LOOSE (curse — leaky pockets) |
| 46 | MAGIC_SLOWTIME (spell duration x2) |
| 47 | MAGIC_PERCEPTION |
| 48 | MAGIC_MANASHIELD |
| — | MAGIC_IMMORTALITE, MAGIC_VIELLESSE, MAGIC_FAMINE, MAGIC_LENTEUR, MAGIC_ZIZANIE |
| — | MAGIC_SPECIAL_CONFUSION / STONE / TEMPETE (on-hit spell style) |

TrueStone stamps **safe** IDs 40–44, 46–48 only (no curses).

## ITEMOBJECT.DAT
- Stride **394**, name at record start, LEVEL at **+278**, combat at +184/+186/+188.
- Effect feature field offset is **discovered at runtime** by counting shorts in 40–60 across records.
- `stampPermaEffects` writes into empty or existing magic-feature slots.

## Verify
After install, identify gear in town. If no perma names appear, capture ITEMOBJECT.DAT and we lock the offset.

## Respawn (related)
PC does not truly respawn on kill like PSX fix; CHAAPP/CNTAPP boost is a soft assist.
EXE on-kill / on-land-complete repop is **DCP-025 research** (no stable site yet — no RESPAWN string in EXE).
