# FF-style baseline (v1.13.2)

ChatGPT care package (Darkstone.zip) contributed the first FF pass; merged and extended:

| Feature | Behavior |
|---------|----------|
| **FF player bases** | BASE_* × 160–220% (class identity kept); **BASE_LIFE floor 100** |
| **FF enemy compensation** | Combat scaled from **LEVEL (+66)** after family LEVEL shuffle — not legacy power-rando |
| **Start-level feel** | `levelMult` scaled for band ~3–8 (no true start-level field in PCLASS) |
| **Start kits** | 3–4 of 4 slots filled when Start kits on |

Stock DATA from care package: `CD/MONSTERCLASS.DAT`, `ITEMOBJECT.DAT`, `PCLASS/`.

Power randomization remains **off**.
