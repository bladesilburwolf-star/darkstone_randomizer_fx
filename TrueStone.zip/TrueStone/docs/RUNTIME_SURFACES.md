# PC runtime surfaces (consistency)

| File | Runtime? | TrueStone uses |
|------|----------|----------------|
| **MONSTERCLASS.DAT** | Yes — combat | All monster power, types, packs, speed, elites, spells, equip, block |
| **ITEMOBJECT.DAT** | Yes — items/loot | Dmg/AC/LEVEL/prices/perma |
| **PCLASS.TXT** | Yes — class table | levelMult, foodMax, hit/block, start kits, class improve |
| MONSTER.TXT | No (editor export) | **Removed from pipeline** |
| OBJECT.TXT | No (editor export) | **Removed from pipeline** |
| SCRIPT/*.SPT | Yes if in MTF | Density, ambush, quest land, rewards |
| LAND/*.O3D | Yes if in MTF | Prop mesh shuffle |
