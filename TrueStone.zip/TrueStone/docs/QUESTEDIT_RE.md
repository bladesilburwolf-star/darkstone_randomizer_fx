# QuestEdit.exe reverse notes (official tool)

Source: Delphine `QuestEdit.exe` (~1 MB). Registry: `SOFTWARE\DelphineSoft\Darkstone\CurrentVersion\Darkstone`.

## Dungeon / land surfaces (answers layout problems)

| Asset | Path / form | Role |
|-------|-------------|------|
| **CBS packs** | `questEditor\cbs\level1a.cbs` … `level4a.cbs`, `land.cbs` | Editor collision / theme packs per floor tier |
| **Runtime theme IDs** | Game EXE strings `level1a`–`level1d`, `level2a`–`d`, `level3a`–`d`, `level4a`… | **Same length** — theme variant pool for dungeon visuals |
| **SPT emit templates** | `LAND {%d}`, `LEVEL { %d }`, `ROOM {%s}`, `MESH {%s}`, `FLAG { LEVEL }` | How QuestEdit writes SCRIPT |
| **Room rules** | One entrance per dungeon; rooms on a floor must stay linked within room; trap placement bounds | Soft-lock constraints for door rando |

CBS is **editor-side**; the **game** loads theme meshes via `levelNa` IDs and `data\level2a\meshes\...` style paths (see main EXE).

## Music / sound (Wind Waker–style shuffle)

| Asset | Path |
|-------|------|
| Music tracks | `music\%02d.mp2` + archive **`music.mtf`** |
| Voices | `voices\%s.mp2`, `voices%1d\%c%s_%d.mp2` |
| Custom quest music | `data\customQuest\%s\%s.mp2` |
| SFX | `data\sound\%s.wav`, **`data\snd.dat`** |

Shuffle strategy: **same-size** file swap inside `music.mtf` / `data\sound\` or renumber `%02d.mp2` with matching sizes.

## Player / NPC models

| Asset | Path |
|-------|------|
| Skeleton set | `data\skeletons\%s\%s.{ska,anb,mdl,mbr}` |
| Addon | `data\skeletons\%s\addon` |
| Custom meshes | `data\custom\meshes\%s.o3d`, `data\customQuest\%s\%s.o3d` |

Same-length **folder** names under `skeletons\` = safe model identity swap (WW-style costume rando).

## Custom quest package layout

```
data\customQuest\<name>\
  questN.spt
  *.o3d / *.cdf / *.mp2
  k0830_sprite.tga
  → may pack to %s\%s.mtf
```

Bank textures: `questEditor\bank\k%04d_OBJ.tga`, `DATA\bankdatabase\dragonblade\`.

## Data files shared with game

- `data\itemobject.dat`, `data\monsterclass.dat`
- `data\trisprite.dat`, `data\snd.dat`
- `data\text\language.dat`

## Implications for TrueStone

1. **Dungeon visual variety** → shuffle `levelNa` theme assignment / same-size meshes under `data\level*\meshes\` when extracted.
2. **Music rando** → `music.mtf` + `music\%02d.mp2` same-size groups.
3. **SFX rando** → `sound\%s.wav` same-size + optional SND.DAT later.
4. **Player model rando** → `skeletons\<id>\` same-length id swap.
5. **Door/floor graph** → respect QuestEdit rules (one entrance, same-room links); pure SCRIPT floor remap remains risky without room graph.
