# Claude conversation — monster types (2026-09-09)

Source: user paste of Claude session (PSX-focused; PC side note).

## User clarification
- **Do not prioritize PC** in that Claude session (PC already ahead of PSX).
- **"Monster level +66"** in player language ≈ **land/dungeon-tier monster type variety** (goblins mixed with wizards, skeleton captains, etc.) — i.e. **who appears where**, not only the per-record LEVEL XP field.
- Current **same-length name shuffle** on PSX: moves one land's monster to another but stays tame.
- **Complete randomization** is the chaos they want to *see*.

## What Claude found (PSX)
`randomizeEnemyTypes` rewrites `MO_*` name references in spawn slots, but only within **exact same text-length** groups (`byCap`).  
GOBLIN vs WIZARD vs SKELETONCAPTAIN rarely share capacity → they **cannot mix**.  
Overflow checks still required for slot byte capacity.

Proposed PSX option: **complete randomization** — any type into any slot **if it fits** the slot capacity (not same-length-only).

## PC mapping (TrueStone) — do not confuse these three knobs

| Knob | Mechanism | Effect |
|------|-----------|--------|
| **LEVEL (+66)** | DAT field shuffle | **Kill XP** payout |
| **Identity / type swap** | Full 584-byte MONSTERCLASS.DAT record shuffle within LMAX bands | Changes **which archetype** a record is (model+stats+gear) |
| **Land spawn roster** | LAND/LEVEL/SCRIPT `MO_*` or spawn lists (if present) | **Which types appear in which land/dungeon** |

PC already has DAT **identity swaps by LMAX tier** (`shuffleEnemyIdentitiesDat`). That is closer to "types per tier" than PSX same-length name shuffle.

Still missing on PC (from player design):
1. **Early combat soft-nerf** independent of power-randomize (density/speed already up).
2. **Invasion / gamble**: 1/7–1/10 chance later-tier types appear in early lands, **scaled down**.
3. Explicit UI modes: **Tier shuffle** vs **complete type chaos** (like Claude's PSX option).

## Consistency rule
Never treat MONSTER.TXT-only name edits as runtime type changes on PC. Runtime = **DAT** (+ real spawn lists when mapped).
