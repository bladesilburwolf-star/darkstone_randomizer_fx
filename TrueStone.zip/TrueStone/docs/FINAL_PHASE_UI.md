# Final phase UI (v1.14.0)

## Theme
FFVII-inspired deep teal/cyan field + **platinum** frame and tab strip (`theme.css`).

## Top tabs
| Tab | Contents |
|-----|----------|
| **Start Run** | Seed, presets, quick launch (Bloodstained-style) |
| **Balance** | FF player/enemy, family LEVEL/XP, speeds/spawns, items, QoL |
| **World** | SCRIPT traps/visuals, quest density (no level doors) |
| **For Fun** | Density+, elites, ambush, mon spells/perma/equip |
| **Install** | MTF/pipeline, randomize/install/launch |
| **MTF** | Explorer |

## Removed from UI
- Level doors (within/cross) — non-working on PC
- Legacy combat power randomization controls
- Cluttered Advanced module laundry list (trimmed)

## Still planned
Graphics/SFX/music asset randomizers; further QoL EXE patches.
