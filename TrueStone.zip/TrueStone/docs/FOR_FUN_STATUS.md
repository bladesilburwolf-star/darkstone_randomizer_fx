# For Fun / related feature status

Verified in-game **2026-09-09** (clean DATA overrides + DATA.MTF):

| Feature | Status |
|---------|--------|
| Monster repop boost (CHAAPP/CNTAPP) | **OK** |
| Stamp perma effects on gear | **OK** (offset discovery found a live field) |
| For Fun → Dungeon pack density+ | **OK** |

Still sequential / not confirmed this session:

| Feature | Status |
|---------|--------|
| For Fun → More elite monsters | **OK** (verified) |
| For Fun → Ambush chests (KF-style) | **Shipped v1.10.6** — await playtest |

Boot rule: always keep a clean DATA.MTF + no loose DATs baseline before stacking options.

| For Fun → Monster attack spells | **Shipped v1.11.0** — await playtest |
| For Fun → Monster perma effects | **Shipped v1.11.0** — await playtest |

## Verified 2026-09-09 (night)
- **Monster attack spells**: confirmed in-game — Level 1 fire chaos / Game Over. Casters live.
- **Next balance pass**: lower monster spell chance and/or early-game spell pool; soft-cap dmg on spell-enabled trash; keep chicken rare. Pair with existing monsterPowerScale / Expert nuke.

- **Teleport chaos** (2026-09-09): AI+spell stamp caused blink spam, not firestorm. v1.11.2 lowers chance, prefers vanilla WIZA spell ids 4/7, only sets AI=2 on melee defaults.

## v1.11.3
- Monster **equipment shuffle** (attack +342 / weapon +406 by model family)
- Spells: only WIZA-proven ids 4/7/2/5, AI always 2, chance 25%

## Next phase (after balance lock) — player 2026-09-09

Not started until family-tier / soft-nerf / XP feel right in play.

1. **SFX randomization**
2. **Music randomization**
3. **Dungeon/land textures** (visual variety — **not** land tiles)
4. **Dungeon layouts** more randomized (**not** overworld land tiles)

Keep army-migration type swaps off; within-family tiers are the combat model.
