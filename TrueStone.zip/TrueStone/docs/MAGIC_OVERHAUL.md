# Magic overhaul (v1.15.0)

## Working surfaces
| Feature | Where |
|---------|--------|
| Spell book LEVEL→1 | ITEMOBJECT `ITEM_BOOK_*` / `ITEM_SCROLL_*` (+278) |
| Book stands shuffle | SCRIPT `ITEM_BOOK_*` refs same-length |
| Spell damage scale | SCRIPT `DAMAGE {a,b}` ×1.5–2.5 |
| Duration/timers | SCRIPT `TIMER {n}` for n≥50 ×1.5–3.0 |
| Loot pool | Books at LEVEL 1 so engine can roll them |

## Limits
Player spell **definitions** (mana cost, base duration of cast spells) live largely in the **EXE** (`SPELL_*` names, `spellDef`). Full uncap of cast Fireball/Haste still needs EXE table mapping. SCRIPT path strongly affects **trap/projectile magic** and quest effects.
