# Monster overhaul (PC — MONSTERCLASS.DAT)

Runtime combat is **DAT only**. MONSTER.TXT edits alone do **not** change fights.

## What actually works (install `data\monsterclass.dat`)

| Feature | Mechanism |
|---------|-----------|
| **Enemy types** | Full **584-byte record swaps** within LMAX bands |
| **Spawn packs** | CNTAPP (+216) + CHAAPP (+214) |
| **Speeds / power / elites / spells / equip / block** | DAT field writes |

## What was broken
TXT-only key/stat shuffles never affected combat. PSX FE/door heuristics do not apply.

## Claude session takeaway (2026-09-09)
Player wants **visible type mix** (goblin + wizard + skeleton captain), not only XP LEVEL tags.
PSX lesson: same-length `MO_*` shuffle is too tame; need a **complete randomization** mode (fit capacity, not same length).
PC: DAT identity swap by LMAX is the real type mixer; add **invasion odds** for later types in early lands + early soft-nerf (density already high).
See `CLAUDE_CONV_MONSTER_TYPES.md`.


## Playtest lock-in (2026-09-09 evening)

**Family tiers work** (basic shuffle mode):
- Spark fly (later tier) in place of land-1 generic fly — still a fly, not OP
- Shield skeletons early level 2 — present, not terrible
- Darker green goblins vs lighter — same family visual/tier mix
- Overworld density up; power not army-migration

**Modes:**
1. **Family tiers** (default) — AoS-style within-type variety, ~3–5 tiers per family
2. **Full type chaos** (secondary checkbox) — cross-family invasions, rare + scaled

Do not re-enable whole-roster identity swaps as default.
