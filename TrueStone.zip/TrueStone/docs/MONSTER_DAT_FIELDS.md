# MONSTERCLASS.DAT field map (clean GOG dump, 2026-09-09)

Stride **584**, first record at offset **8**.

| Off | Field | Notes |
|-----|-------|-------|
| 0–31 | key | ASCII name |
| 68/72 | LMIN/LMAX | level band |
| 76 | AC | |
| 80 | TOHIT | |
| 84/88 | DMIN/DMAX | |
| 214 | CHAAPP | spawn chance |
| 216 | CNTAPP | spawn count |
| 534 | SPEED | |
| **538** | **AI / behavior** | `-1` melee default; **`2` = caster (WIZA*)**; `4` reflection-style |
| **550** | **Spell id** | EXE `SPELL_*` index; WIZA uses 4/7 |
| **558 / 562** | **Mana pool** | casters often 50/50 |

## For Fun monster spells
Set `+538=2`, `+550=<spell>`, `+558/+562=40–80`.

| +32 | model skeleton | STAMAZONE, MO_SKELETON1, … |
| +342 | attack anim | BOWFIRE, SWING, SKELATTACK (32-byte string) |
| +406 | weapon attach | S_SWORD, S_SHIELD, S_STAFF (32-byte string) |
