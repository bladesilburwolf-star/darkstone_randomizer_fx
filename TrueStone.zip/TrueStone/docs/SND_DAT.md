# SND.DAT / sound assets

## SND.DAT layout
- Header: 6 bytes (`u16 version=1`, `u16 count=247`, +2)
- Records: **34 bytes** × count
  - `u16` flag (usually 1)
  - **32-byte** sound name (null or `0xCD` padded)
- Names map to `data\sound\%s.wav` (QuestEdit / game EXE)

## TrueStone shuffle
**Same-length name swap** inside SND.DAT — engine requests different WAV paths without needing the full sound folder extracted.

## SOUND.TXT (dir listing)
~175 WAVs; **14 same-size groups** for binary file swap when `data/sound/` is present (e.g. punch1–4 different sizes; ITEM_USE/PICK/DROP @ 7102; SPELL/ASTRAL @ 47340).

## Also stocked
- `OBJ3D.DAT` — 3D object name index (A01, BOW, BOOK, …)
- `TRISPRITE.DAT` — UI sprite definitions (leave alone unless sprite rando)
