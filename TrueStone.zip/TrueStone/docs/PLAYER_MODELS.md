# Player model replacer (v1.16.1)

## Working
**Hero skeletons only** via `PCLASS skelBaseName`:
`KNIGHT AMAZONE MAGE SORCIERE ASSASSIN ROGUE MOINE PRETRESS`

| Mode | Behavior |
|------|----------|
| Shuffle heroes | Permute the 8 vanilla bodies across classes |
| Random hero | Each class picks any of the 8 (duplicates OK) |

## Not supported
Monster / Halloween costumes (`MO_WEREWOLF`, `MO_VAMPIRE`, `MO_BAT`, `MO_SKELETON*`, …) **error in-game**.
Those packs lack player animation states (`marche`, `course`, `attackF`, lycan overlay, etc.).
UI options remain visible but disabled for documentation.

## Future
Would need full player-compatible anim sets (or EXE lycan path only for werewolf talent), not a simple skelBaseName redirect.
