# Equipment model shuffle (Vagrant Story style)

## What changes
ITEMOBJECT.DAT appearance only — **stats stay on the item**:

| Offset | Field | Example |
|--------|-------|---------|
| +116 | Inventory sprite | `SPRITE_AXE1H`, `SPRITE_SWORD1H_12` |
| +150 | 3D mesh key (OBJ3D) | `W06`, `W11`, `A02`, `XBOU01` |
| +320 | Equip SFX | `S_AXE`, `S_SWORD`, `S_BOW` |

A sword can look and sound like an axe; armor pieces can swap shells.

## Modes
- **Full chaos** (default when enabled): one pool of all equip rows
- **Grouped**: WEAPON / ARMOR / SHIELD / JEWEL / BOOK / SPECIAL

## Not touched
Attack anim at +352 (`SWING`, `BOWFIRE`) — keeps combat type sane.
Combat numbers, LEVEL (+278), prices, perma IDs.
