# Equip & skill notes (TrueStone PC)

Player observations for future RE / rando hooks.

## Skills
- Skills are **class-locked** today — cannot freely reassign skill trees without deeper PCLASS / talent table work.
- **Prayer** increases **armor rating** (AC-related passive).
- **Silence** is the thief skill tied to **walking / stealth** movement.
- Talent rows already exist in `PCLASS.TXT` as `SPELL_TALENT_*` (Identifier, Commerce, Repair, Perception, Disarm, …).

## Weapons / armor effects
- Later difficulties (especially **Expert** and **Hero**) introduce:
  - **Spell-effect** weapons/armor (on-hit casts: Magic Missile, Storm, Confusion, Fire, Poison, …)
  - **Permanent (perma) effects** (Abundance, Eternal Youth, Permanent Perception, Mana Shield, Vampire, …)
- Cursed gear starts appearing more from **Expert** upward.
- Base templates live in `OBJECT.TXT` / `ITEMOBJECT.DAT` (LEVEL gate at DAT offset **+278**, stride **394**).
- **Enchantment rolls** at drop/shop time are still largely driven by **session difficulty** in the EXE — not fully exposed in TXT columns.

## TrueStone hooks
| Option | Behavior |
|--------|----------|
| `itemLevelUnlock` + reduction | Lowers LEVEL reqs globally by preset |
| `releaseExpertHeroGear` | Combat items with LEVEL ≥ `expertHeroLevelGate` (default 35) forced to `expertHeroReleaseLevel` (default 5) in TXT + DAT |

That **releases high-tier base weapons/armor** into Novice/Expert play. Full on-hit spell/perma **tables** still need loot-gen RE (or dual combat/loot difficulty) before every Expert/Hero enchantment appears on Novice drops.

## Hidden attributes (to find)
- Min difficulty for enchantment tiers
- Effect ID / perma vs on-hit flags in ITEMOBJECT.DAT
- Curse roll weight by difficulty
- Prayer → AC coefficient
- Silence / walk noise fields
