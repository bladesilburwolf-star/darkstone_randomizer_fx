# Retail SCRIPT / PROJECTILE / PATTERN (2026-09-09)

User-provided extracts:

| Pack | Role |
|------|------|
| **SCRIPT/** | Quest + dungeon SPT (TRAP state machines, OBJECT, PROJECTILE KEY, EFFECT) |
| **PROJECTILE/** | Effect/weapon projectile `.O3D` meshes (same-size groups swappable) |
| **PATTERN/** | UI/pattern meshes + `BOOKSPELL.O3D`, inventory, etc. |

## Trap model (from FC5_DAMNES / MEDUSA / ENTREE)
```
TRAP {
  KEY { ... }
  FLAG { LIGHT|ACTIVE|... }
  SKELFILE { spctrap1 }
  STATE { ... ACTION { TELEPORT2ND / HIT / PROJECTILE / EFFECT } ... }
}
```

## TrueStone v1.12.9
- Bundled `reference/SCRIPT` used if game has no SCRIPT folder
- **ENTREE.SPT** included in trap passes (was excluded)
- Shuffle **SKELFILE / SKELNAME / EFFECT / SOUND** same-length
- Shuffle **PROJECTILE KEY** (fireball, magicmiss, …)
- Light **HIT { n }** jitter
- CHANGELEVEL destinations still protected

## Install
Merge randomized `Out/SCRIPT/*.SPT` into DATA.MTF. Optional: same-size shuffle PROJECTILE O3D under `data/PROJECTILE/`.
