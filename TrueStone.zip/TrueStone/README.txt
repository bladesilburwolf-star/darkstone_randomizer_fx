TrueStone PC Randomizer  v1.18.0
================================
Darkstone (PC) randomizer — Vagrant Story / King’s Field / Bloodstained style.
1.x feature line complete.

REQUIREMENTS
  - Windows + Darkstone PC (GOG or retail)
  - Java 17 or newer
  - OpenJFX 21+ SDK  https://gluonhq.com/products/javafx/

QUICK START
  1. Extract this folder anywhere (not inside Program Files if UAC is annoying).
  2. Download JavaFX Windows x64 SDK and either:
       - Extract so you have:  TrueStone\javafx\lib\javafx.controls.jar
       - Or set:  set JAVAFX_HOME=C:\path\to\javafx-sdk\lib
  3. Double-click TrueStone.bat
  4. Browse to your Darkstone game folder, set seed, Randomize.
  5. Install output: inject DATA.MTF and/or copy Out\data\ overrides.

WHAT’S IN
  - Seed pipeline + MTF tools
  - Family-tier monster LEVEL/XP, FF-style player baselines
  - Magic overhaul, SCRIPT traps, trapped books, open-cast spells
  - Vagrant Story equipment mesh/sprite shuffle
  - Hero model shuffle (monster costumes not supported)
  - SND.DAT / optional music-SFX shuffle
  - For Fun: mimics, density, elites

REFERENCE
  reference\ holds SCRIPT / stock DAT samples used when the game folder
  does not already have extracts.

DOCS
  docs\ — design notes and release history

NOTE
  A single-file .exe needs jpackage on a Windows machine with JDK+JavaFX
  (see docs\JPACKAGE.txt). The .bat + jar is the supported ship form.
