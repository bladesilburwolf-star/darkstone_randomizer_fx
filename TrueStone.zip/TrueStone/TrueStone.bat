@echo off
setlocal EnableExtensions
title TrueStone PC Randomizer v1.18.0
cd /d "%~dp0"

if defined JAVA_HOME (
  set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
) else (
  set "JAVA_EXE=java"
)

if not defined JAVAFX_HOME if exist "%~dp0javafx\lib" set "JAVAFX_HOME=%~dp0javafx\lib"
if not defined JAVAFX_HOME if exist "C:\javafx-sdk-21\lib" set "JAVAFX_HOME=C:\javafx-sdk-21\lib"
if not defined JAVAFX_HOME if exist "C:\javafx-sdk-26\lib" set "JAVAFX_HOME=C:\javafx-sdk-26\lib"
if not defined JAVAFX_HOME if exist "C:\javafx-sdk-26.0.2\lib" set "JAVAFX_HOME=C:\javafx-sdk-26.0.2\lib"

if not defined JAVAFX_HOME (
  echo.
  echo [TrueStone] JavaFX not found.
  echo Download OpenJFX 21+ SDK from https://gluonhq.com/products/javafx/
  echo Then either:
  echo   - Extract to TrueStone\javafx\  so javafx\lib exists
  echo   - Or: set JAVAFX_HOME=C:\path\to\javafx-sdk\lib
  echo.
  pause
  exit /b 1
)

"%JAVA_EXE%" --module-path "%JAVAFX_HOME%" --add-modules javafx.controls,javafx.graphics,javafx.base -jar "%~dp0lib\TrueStone.jar" %*
if errorlevel 1 (
  echo.
  echo [TrueStone] Launch failed. Need Java 17+ and matching JavaFX.
  pause
)
endlocal
